﻿using UnityEngine;

public class PatrolState : IState
{
    private float timer;
    private float randomTime;

    public void OnEnter(Enemy enemy)
    {
        timer = 0;
        randomTime = Random.Range(3f, 6f); // Đi tuần từ 3s đến 6s
    }

    public void OnExecute(Enemy enemy)
    {
        // Cộng dồn thời gian đã đi tuần
        timer += Time.deltaTime;

        // Nếu chưa hết thời gian thì tiếp tục đi
        if (timer < randomTime)
        {
            enemy.Moving();
        }
        else // Hết thời gian thì đứng lại (về Idle)
        {
            enemy.ChangeState(new IdleState());
        }
    }

    public void OnExit(Enemy enemy)
    {
    }
}
