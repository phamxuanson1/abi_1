using System;
using UnityEngine;

public class Character : MonoBehaviour
{
    private float hp;
    private bool isDead => hp <= 0;
    private string currentAnimName;
    [SerializeField] private Animator anim;



    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Start()
    {
        OnInit();
    }

    public virtual void OnInit()
    {
        hp = 100;
    }

    public virtual void OnDespawn()
    {
    }

    protected virtual void OnDeath()
    {
    }

    protected void ChangeAnim(string animName)
    {
        if (currentAnimName != animName)
        {
            anim.ResetTrigger(animName);
            currentAnimName = animName;
            anim.SetTrigger(currentAnimName);
        }
    }

    public void OnHit(float damage)
    {
        if (!isDead)
        {
            hp -= damage;
            if(isDead)
            {
                OnDeath();
            }
        }
    }


}
